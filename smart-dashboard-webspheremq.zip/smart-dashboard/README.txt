dashboard-server-1.2.6.beta.jar

1. Installation and server start
--------------------------------
1. Please make sure that java 8+ is installed
2. Unzip the file into a directory
3. Start the server by typing the command
   java -jar dashboard-server-1.2.6.beta.jar
4. Open http://host:8080 on a browser.
5. One the UI is initialized, it should prompt for controller details.
   If not, please click on the cog(gear) icon on the right-top corner of the screen

2. Change the Port
------------------
-Dserver.port=8080

java -Dserver.port=8080 -jar  dashboard-server-1.2.6.beta.jar

3. Enable Local Login
-----------------
These params can be added as a system property to set the parameters of the server

-Dserver.port=8080
-Ddashboard.security.enabled=false  # This will create a local login with the following credentials.
-Ddashboard.username=user
-Ddashboard.password="deFAultPwd4Da&hb0Rd"
-Ddashboard.security.encryption-key=mykey
-Ddashboard.security.encryption-salt=mykey

java -DpropName=propVal -jar  dashboard-server-1.2.6.beta.jar

4. Forward Proxy Support
----------------------
Please use the following args to use with a forward proxy.

-Dhttp.proxyHost=<proxy-host>
-Dhttp.proxyPort=<proxy-port>

Optional. Please use these args for an authenticating proxy.
-Dhttp.proxyUser=<optional-proxy-user>
-Dhttp.proxyPassword=<optional-proxy-password>

5. Other properties
-Dhttp.connect.timeout=2000
-Dhttp.read.timeout=300000


5. Dashboards for AppDynamics Extensions
-------------
The dashboards are hosted in a directory named dashboards. The configuration instructions will follow in the next version.
Open the file "dashboards/$DASHBOARD/config.json" and update the following attributes
{
 "application": "",
 "basePath": ""
 ....
}
application: The name of the application. For SIM application use "Server & Infrastructure Monitoring"
basePath: For extension dashboards, just need to update the TierName, which is the 2nd path element as shown.
         eg. Application Infrastructure Performance|$TIER_NAME|Custom Metrics|Docker